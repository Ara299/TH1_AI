package AI_THB1_agentAB.task1;

public abstract class Action {
	public abstract boolean isNoOp();
}