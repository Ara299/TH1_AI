package AI_THB1_agentAB.task2;

public abstract class Action {
	public abstract boolean isNoOp();
}